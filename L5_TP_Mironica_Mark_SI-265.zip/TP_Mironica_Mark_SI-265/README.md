# TP – Mironica Mark, grupa SI-265

Tehnici de programare (S.O.001), UTM · FCIM · Securitate informatică, anul I.
Laboratoarele sunt în folderele `Laborator_N/`. Laboratorul 5: forensics și steganografie.
