# -*- coding: utf-8 -*-
"""Lucrarea B, pasii B1-B4: magic bytes, strings, EXIF/GPS, file carving.
Se ruleaza din Laborator_5/:   python forensics.py
"""
import io
import re
import zipfile
from pathlib import Path

from PIL import Image
from PIL.ExifTags import TAGS

PROBE = Path(__file__).resolve().parent / "probe"

SEMNATURI = [
    (b"%PDF", "pdf"),
    (b"\x89PNG", "png"),
    (b"\xff\xd8", "jpeg"),
    (b"PK\x03\x04", "zip/docx"),
]


# ---------------------------------------------------------------- B1
def tip_real(cale):
    """Tipul dupa semnatura (magic bytes), nu dupa extensie."""
    with open(cale, "rb") as f:               # "rb": fisier binar
        cap = f.read(8)
    for semn, nume in SEMNATURI:
        if cap.startswith(semn):
            return nume, cap.hex()
    return "necunoscut", cap.hex()


# ---------------------------------------------------------------- B2
def strings(cale, minim=4):
    date = Path(cale).read_bytes()
    return [m.decode() for m in re.findall(rb"[ -~]{%d,}" % minim, date)]


# ---------------------------------------------------------------- B3
def dms_la_zecimal(dms, ref):
    grade, minute, secunde = (float(x) for x in dms)
    val = grade + minute / 60 + secunde / 3600
    return -val if ref in ("S", "W") else val


def exif_si_gps(cale):
    img = Image.open(cale)
    exif = img.getexif()
    meta = {TAGS.get(i, i): v for i, v in exif.items()}
    gps = exif.get_ifd(34853)                 # blocul GPS
    coord = None
    if gps:
        lat = dms_la_zecimal(gps[2], gps[1])
        lon = dms_la_zecimal(gps[4], gps[3])
        coord = (lat, lon, gps[1], gps[3])
    return meta, coord


# ---------------------------------------------------------------- B4
def carve_zip(cale, iesire="gasit.zip"):
    """Cauta semnatura ZIP dupa sfarsitul PNG-ului (chunk IEND)."""
    date = Path(cale).read_bytes()
    start = date.find(b"IEND") + 8 if b"IEND" in date else 0   # IEND + CRC
    i = date.find(b"PK\x03\x04", start)
    if i == -1:
        return None
    Path(iesire).write_bytes(date[i:])
    with zipfile.ZipFile(io.BytesIO(date[i:])) as z:
        continut = {n: z.read(n).decode(errors="replace") for n in z.namelist()}
    return i, continut


def main():
    print("== B1 tipul real")
    for f in ("foto.jpg", "ascuns.png"):
        print(f"  {f}: {tip_real(PROBE / f)}")

    print("== B2 strings din ascuns.png (ultimele 6 secvente)")
    for s in strings(PROBE / "ascuns.png")[-6:]:
        print("  ", s)

    print("== B3 EXIF foto.jpg")
    meta, coord = exif_si_gps(PROBE / "foto.jpg")
    for k, v in meta.items():
        print(f"  {k} = {v}")
    if coord:
        lat, lon, rlat, rlon = coord
        print(f"  Latitudine : {abs(lat):.6f} {rlat}")
        print(f"  Longitudine: {abs(lon):.6f} {rlon}")
        print(f"  Harta: https://www.openstreetmap.org/?mlat={lat}&mlon={lon}")

    print("== B4 file carving din ascuns.png")
    rez = carve_zip(PROBE / "ascuns.png")
    if rez:
        i, continut = rez
        print("  arhiva extrasa de la octetul", i)
        for nume, txt in continut.items():
            print(f"  {nume}: {txt.strip()}")
    else:
        print("  nu s-a gasit nicio arhiva")


if __name__ == "__main__":
    main()
