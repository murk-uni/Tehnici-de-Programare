# -*- coding: utf-8 -*-
"""Decoder universal (Lucrarea A): recunoaste si desface straturi de codare
(url / hex / base64), sparge XOR cu cheie de un octet si hash-uri prin dictionar.

Folosire:
    python arsenal/forensics/decode.py "U2FsdXQ="
    python arsenal/forensics/decode.py --fisier probe/mesaj.txt
"""
import argparse
import base64
import binascii
import hashlib
import json
import re
from pathlib import Path
from urllib.parse import unquote

AICI = Path(__file__).resolve().parent          # arsenal/forensics/
PROBE = AICI.parents[1] / "probe"                # Laborator_5/probe/
ALGORITMI = {32: "md5", 40: "sha1", 64: "sha256"}


# ---------------------------------------------------------------- A1
def text_si_octeti():
    s = "Salut"
    b = s.encode()
    print(b, b[0])                     # b'Salut' 83
    h = b.hex()
    print(h, bytes.fromhex(h))         # 53616c7574 b'Salut'


# ---------------------------------------------------------------- A2
def ghici_strat(s):
    """Clasifica dupa forma: url -> hex -> base64 (de la strict la larg)."""
    if isinstance(s, (bytes, bytearray)):
        s = s.decode("latin1")
    s = s.strip()
    if re.search(r"%[0-9A-Fa-f]{2}", s):
        return "url"
    if re.fullmatch(r"(?:[0-9a-fA-F]{2})+", s):
        return "hex"
    if re.fullmatch(r"[A-Za-z0-9+/]+={0,2}", s) and len(s) % 4 == 0:
        return "base64"
    return "necunoscut"


# ---------------------------------------------------------------- A3
def desfa(s):
    """Desface UN strat. Intoarce (strat, rezultat_bytes)."""
    if isinstance(s, (bytes, bytearray)):
        s = s.decode("latin1")
    s = s.strip()
    strat = ghici_strat(s)
    try:
        if strat == "base64":
            return strat, base64.b64decode(s, validate=True)
        if strat == "hex":
            return strat, bytes.fromhex(s)
        if strat == "url":
            return strat, unquote(s).encode()
    except (binascii.Error, ValueError):
        pass                            # forma semana a codare, dar nu e
    return "necunoscut", s.encode()


# ---------------------------------------------------------------- A4
def citibil(b):
    """True daca toti octetii sunt in 32..126 (ASCII imprimabil)."""
    return len(b) > 0 and all(32 <= c < 127 for c in b)


def desfa_straturi(val, maxim=8):
    """Desface in bucla cat timp urmatorul strat da tot text citibil.
    Intoarce (lista_straturi, rezultat_bytes)."""
    curent = val.encode() if isinstance(val, str) else bytes(val)
    straturi = []
    for _ in range(maxim):
        strat, urmator = desfa(curent)
        if strat == "necunoscut" or not citibil(urmator):
            break                       # nu mai e strat, sau n-ar iesi text
        straturi.append(strat)
        curent = urmator
    return straturi, curent


# ---------------------------------------------------------------- A5
def scor_text(b):
    """Cat de mult seamana cu text: litere mici, spatii si cifre valoreaza
    mult, majusculele putin, restul de semne imprimabile nimic."""
    pts = 0
    for c in b:
        if 97 <= c <= 122 or c == 32:
            pts += 2
        elif 65 <= c <= 90 or 48 <= c <= 57:
            pts += 1
    return pts / len(b)


def sparge_xor(date, filtru=citibil):
    """Incearca toate cele 256 de chei de un octet. Intoarce [(cheie, clar)]
    doar pentru cele care trec filtrul, ordonate dupa scor_text (cel mai bun
    primul). Filtrul 'imprimabil' singur NU e unic: mai multe chei pot trece."""
    gasite = []
    for k in range(256):
        clar = bytes(b ^ k for b in date)
        if filtru(clar):
            gasite.append((k, clar))
    gasite.sort(key=lambda kc: scor_text(kc[1]), reverse=True)
    return gasite


# ---------------------------------------------------------------- A6
def alg_dupa_lungime(h):
    return ALGORITMI.get(len(h.strip()))


def sparge_hash(tinta, cuvinte):
    """Atac cu dictionar: hashuiesti fiecare cuvant si compari."""
    tinta = tinta.strip().lower()
    alg = alg_dupa_lungime(tinta)
    if alg is None:
        return None, None
    for cuv in cuvinte:
        cuv = cuv.strip()
        if hashlib.new(alg, cuv.encode()).hexdigest() == tinta:
            return alg, cuv
    return alg, None


# ---------------------------------------------------------------- A7
def main():
    p = argparse.ArgumentParser(description="Decoder universal")
    p.add_argument("intrare")                       # sir sau cale
    p.add_argument("--fisier", action="store_true")  # intrarea e o cale
    p.add_argument("--fisa", default=str(AICI / "fisa.json"))
    a = p.parse_args()

    if a.fisier:
        data = Path(a.intrare).read_bytes().decode("latin1").strip()
    else:
        data = a.intrare

    straturi, rez = desfa_straturi(data)
    text = rez.decode("latin1")
    fisa = {"strat": ">".join(straturi) if straturi else "necunoscut",
            "straturi": straturi, "rezultat": text}
    Path(a.fisa).write_text(json.dumps(fisa, ensure_ascii=False, indent=2),
                            encoding="utf-8")
    print("straturi:", straturi or "niciunul")
    print("rezultat:", text)
    print("fisa salvata in", a.fisa)


if __name__ == "__main__":
    main()
