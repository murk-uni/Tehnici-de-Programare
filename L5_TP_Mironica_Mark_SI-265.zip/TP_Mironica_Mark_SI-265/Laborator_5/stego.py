# -*- coding: utf-8 -*-
"""Lucrarea B, pasii B5-B6: steganografie LSB.
   python stego.py ascunde            # probe/foto.jpg + mesaj -> stego.png
   python stego.py dezvaluie          # citeste mesajul din stego.png
"""
import sys
from pathlib import Path

from PIL import Image

AICI = Path(__file__).resolve().parent
MESAJ = b"FLAG{ascuns_in_pixeli}"


def _pixeli(img):
    # get_flattened_data() in Pillow >= 12.1, getdata() in cele vechi
    return list(img.get_flattened_data() if hasattr(img, "get_flattened_data")
                else img.getdata())


# ---------------------------------------------------------------- B5
def ascunde(gazda, mesaj, iesire):
    img = Image.open(gazda).convert("RGB")
    canale = [c for p in _pixeli(img) for c in p]
    biti = "".join(f"{x:08b}" for x in mesaj + b"\0")      # \0 = final de mesaj
    if len(biti) > len(canale):
        raise ValueError("mesaj prea lung pentru imaginea gazda")
    for i, bit in enumerate(biti):
        canale[i] = (canale[i] & ~1) | int(bit)
    img.putdata([tuple(canale[i:i + 3]) for i in range(0, len(canale), 3)])
    img.save(iesire)                                       # PNG = fara pierdere
    return len(biti)


# ---------------------------------------------------------------- B6
def dezvaluie(cale):
    biti = ""
    for r, g, b in _pixeli(Image.open(cale).convert("RGB")):
        biti += f"{r & 1}{g & 1}{b & 1}"
    octeti = bytearray()
    for i in range(0, len(biti) - 7, 8):
        o = int(biti[i:i + 8], 2)
        if o == 0:                                         # final de mesaj
            break
        octeti.append(o)
    return bytes(octeti)


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "ambele"
    if cmd in ("ascunde", "ambele"):
        n = ascunde(AICI / "probe" / "foto.jpg", MESAJ, AICI / "stego.png")
        print(f"ascuns: {MESAJ.decode()}  ({n} biti) -> stego.png")
    if cmd in ("dezvaluie", "ambele"):
        print("dezvaluit:", dezvaluie(AICI / "stego.png").decode(errors="replace"))
