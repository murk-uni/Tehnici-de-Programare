# pytest: radacina Laborator_5 intra in sys.path
