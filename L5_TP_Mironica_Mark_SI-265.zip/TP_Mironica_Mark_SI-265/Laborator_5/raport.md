# Raport – Laborator 5: forensics și steganografie

**Student:** Mironica Mark · **Grupa:** SI-265

Toate fișierele analizate sunt cele generate de `probe/pregateste.py` (ținte permise de laborator).
Rulare: `python arsenal/forensics/decode.py ...`, `python forensics.py`, `python stego.py`,
teste în `teste/test_decode.py`.

## Lucrarea A – decoderul universal (`arsenal/forensics/decode.py`)

### A1–A4. Straturile din `probe/mesaj.txt`
Comanda: `python arsenal/forensics/decode.py --fisier probe/mesaj.txt`

| Pas | Strat recunoscut | Cum |
|---|---|---|
| 1 | base64 | doar `A-Za-z0-9+/=`, lungime multiplu de 4 |
| 2 | base64 | rezultatul era tot text în alfabet base64 |
| 3 | hex | rezultatul conținea doar `0-9a-f`, lungime pară |
| – | stop | rezultatul `FLAG{...}` conține `{`, deci nu mai e o codare |

**Mesajul ascuns:** `FLAG{straturi_de_encoding}` (lanț `base64 > base64 > hex`).
Fișa salvată în `arsenal/forensics/fisa.json`.

Observații de proiectare:
- Ordinea verificărilor este url → hex → base64 (de la cel mai strict la cel mai larg alfabet).
- Bucla se oprește când următorul strat nu mai dă text citibil, nu la primul text citibil. Altfel s-ar fi oprit după primul base64, care e deja text ASCII.
- Exemplul din enunț `NTM1OTU3NTk=` se desface `base64 > hex` și dă `SYWY`. Un al treilea pas ar da octeți neimprimabili, deci bucla se oprește.

### A5. XOR cu cheie de un octet (`probe/xor.bin`)
Din cele 256 de chei, **17 trec filtrul „toți octeții 32..126”**, deci filtrul singur nu dă un răspuns unic: cheile apropiate de cea reală schimbă doar câțiva biți ai textului. Funcția `sparge_xor` ordonează candidații după un scor de „aspect de text” (litere mici, spații, cifre).

- **Cheia găsită: 128 (0x80)**
- Text clar: `Un singur octet tine tot secretul... gaseste-l! FLAG{xor_un_octet}`

### A6. Hash-uri sparte prin dicționar (`probe/hashuri.txt` + `probe/wordlist.txt`)
Lungimea 32 de caractere indică MD5. Nu se „decriptează” hash-ul: se hashuiește fiecare cuvânt din wordlist și se compară.

| Hash | Parola |
|---|---|
| 5f4dcc3b5aa765d61d8327deb882cf99 | **password** |
| 8621ffdbc5698829397d97767ac13db3 | **dragon** |
| d8578edf8458ce06fbc5bb76a58c5ca4 | **qwerty** |
| 0d107d09f5bbe40cade3de5c71e9e9b7 | **letmein** |
| d0763edaa9d9bd2a9516280e9044d885 | **monkey** |

(Prima parolă cerută de laborator, pentru primul hash: `password`.)

### A7. argparse, fișă JSON, test
- CLI: `decode.py <sir>` sau `decode.py --fisier <cale>`; salvează `{strat, straturi, rezultat}` în `fisa.json`.
- Teste (`teste/test_decode.py`): 8 teste (base64, clasificare, hex/url, straturi multiple, XOR, hash, citibil) – toate trec.

## Lucrarea B – forensics pe fișiere (`forensics.py`) și steganografie (`stego.py`)

### B1. Tipul real
| Fișier | Primii 8 octeți | Tip real |
|---|---|---|
| foto.jpg | `ffd8ffe000104a46` | jpeg |
| ascuns.png | `89504e470d0a1a0a` | png |

### B2. strings
În `ascuns.png`, după `IEND` apar `secret.txt` și `FLAG{ascuns_prin_carving}`: indiciu că după imagine urmează un fișier ZIP.

### B3. EXIF și GPS (`foto.jpg`)
- Make: Apple · Model: iPhone 13 · DateTime: 2026:09:14 10:30:00
- GPS: **47.016667 N, 28.857500 E** (47°1′0″ N, 28°51′27″ E), adică Chișinău.
- Conversie: `grade + minute/60 + secunde/3600`.
- Valoare OSINT: o poză publicată cu EXIF dezvăluie locul și ora; de aceea se șterge EXIF înainte de publicare.

### B4. File carving
Semnătura `PK\x03\x04` a fost găsită la octetul **781** (după chunk-ul `IEND`). Arhiva extrasă în `gasit.zip` conține `secret.txt` cu textul **`FLAG{ascuns_prin_carving}`**.

### B5–B6. LSB (`stego.py`, `stego.png`)
- Gazdă: `probe/foto.jpg` (convertită la RGB, salvată ca PNG, fără pierdere).
- Mesaj: `FLAG{ascuns_in_pixeli}` + octet `\0` ca terminator = 184 de biți, scriși în LSB-ul primelor 184 de canale.
- Diferența față de original: maximum 1 pe canal (imperceptibilă).
- **Mesajul dezvăluit:** `FLAG{ascuns_in_pixeli}`

## Vârful sălii – `probe/challenge.bin`
1. Indiciul spune: base64 peste XOR cu cheie de un octet, plus verificare MD5.
2. `base64.b64decode` → octeți neimprimabili, deci urmează XOR.
3. Se încearcă cele 256 de chei; pentru fiecare candidat se compară `md5` cu `8c4eb02d9dcef7d0ff91d8e4c7fea91b` din `challenge_hint.txt`.
4. Se potrivește doar **cheia 128 (0x80)**: **`FLAG{lant_complet_despicat}`**.

Verificarea prin hash arată de ce filtrul de imprimabile nu e suficient: o cheie de un octet se confirmă prin MD5, nu prin „arată a text”.
