import hashlib
from arsenal.forensics.decode import (ghici_strat, desfa, citibil,
                                      desfa_straturi, sparge_xor, sparge_hash)


def test_base64():
    strat, b = desfa("U2FsdXQ=")
    assert strat == "base64"
    assert b == b"Salut"


def test_ghici():
    assert ghici_strat("%2Fetc") == "url"
    assert ghici_strat("48656c6c6f") == "hex"
    assert ghici_strat("U2FsdXQ=") == "base64"
    assert ghici_strat("FLAG{x}") == "necunoscut"


def test_hex_si_url():
    assert desfa("48656c6c6f") == ("hex", b"Hello")
    assert desfa("%2Fetc%2Fpasswd") == ("url", b"/etc/passwd")


def test_straturi_multiple():
    # base64 -> hex -> text
    val = "NDg2NTZjNmM2Zg=="
    straturi, rez = desfa_straturi(val)
    assert straturi == ["base64", "hex"]
    assert rez == b"Hello"


def test_xor_un_octet():
    clar = b"Un text oarecare, FLAG{test}"
    date = bytes(b ^ 0x80 for b in clar)
    assert (0x80, clar) in sparge_xor(date)


def test_hash_dictionar():
    h = hashlib.md5(b"dragon").hexdigest()
    assert sparge_hash(h, ["abc", "dragon", "x"]) == ("md5", "dragon")
    assert sparge_hash(h, ["abc"]) == ("md5", None)


def test_citibil():
    assert citibil(b"abc") and not citibil(b"\x80abc")


def test_xor_cel_mai_bun_primul():
    clar = b"Un singur octet tine tot secretul... FLAG{xor_un_octet}"
    date = bytes(b ^ 0x80 for b in clar)
    assert sparge_xor(date)[0] == (0x80, clar)
